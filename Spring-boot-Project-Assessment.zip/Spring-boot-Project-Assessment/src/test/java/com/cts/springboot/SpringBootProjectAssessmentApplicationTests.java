package com.cts.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProjectAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
