package com.cts.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.cts.springboot.entity.BankDetailsEntity;
import com.cts.springboot.services.BankDetailsService;


@Controller
public class BankDetailsController {

	@Autowired
	public BankDetailsService service;
	
	@GetMapping("/bankdetails")
	public String showRegistrationForm(Model model) {
		model.addAttribute("bankdetails", service.getBankDetails());
		return "table";
	}
	
//	@GetMapping("/table")
//	public String modelpage(Model model) {
//		model.addAttribute("bankdetails", service.getBankDetails());
//		return "table";
//	}
}
