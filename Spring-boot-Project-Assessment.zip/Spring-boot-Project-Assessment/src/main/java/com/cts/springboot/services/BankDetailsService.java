package com.cts.springboot.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.springboot.entity.BankDetailsEntity;
import com.cts.springboot.repository.BankDetailsRepository;


@Service
public class BankDetailsService {
	
	@Autowired
	public BankDetailsRepository repository;
	
	public List<BankDetailsEntity> getBankDetails(){
		return repository.findAll();
	}

}
